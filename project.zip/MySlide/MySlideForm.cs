using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

using System.Windows.Forms;


namespace MySlide
{
	public class MySlideForm : SlideDialog.SlideDialog
	{
		private System.Windows.Forms.RadioButton radioButton2;
		private System.Windows.Forms.RadioButton radioButton1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label1;
		private System.ComponentModel.IContainer components = null;

		public MySlideForm(Form poOwner, float pfStep) : base(poOwner, pfStep)
		{
			// Cet appel est requis par le Concepteur Windows Form.
			InitializeComponent();

			// TODO�: ajoutez les initialisations apr�s l'appel � InitializeComponent
		}

		/// <summary>
		/// Nettoyage des ressources utilis�es.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Designer generated code
		/// <summary>
		/// M�thode requise pour la prise en charge du concepteur - ne modifiez pas
		/// le contenu de cette m�thode avec l'�diteur de code.
		/// </summary>
		private void InitializeComponent()
		{
			this.radioButton2 = new System.Windows.Forms.RadioButton();
			this.radioButton1 = new System.Windows.Forms.RadioButton();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// radioButton2
			// 
			this.radioButton2.Location = new System.Drawing.Point(8, 56);
			this.radioButton2.Name = "radioButton2";
			this.radioButton2.TabIndex = 7;
			this.radioButton2.Text = "Female";
			// 
			// radioButton1
			// 
			this.radioButton1.Location = new System.Drawing.Point(8, 32);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.TabIndex = 6;
			this.radioButton1.Text = "Male";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(56, 8);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(144, 20);
			this.textBox1.TabIndex = 5;
			this.textBox1.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(40, 16);
			this.label1.TabIndex = 4;
			this.label1.Text = "Name:";
			// 
			// MySlideForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(208, 80);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.radioButton2,
																		  this.radioButton1,
																		  this.textBox1,
																		  this.label1});
			this.Name = "MySlideForm";
			this.ResumeLayout(false);

		}
		#endregion
	}
}

