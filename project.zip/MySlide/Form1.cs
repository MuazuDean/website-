using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace MySlide
{
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button2;
		MySlideForm _oSlideForm;
		private System.Windows.Forms.Label label1;
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			InitializeComponent();

			_oSlideForm = new MySlideForm(this, 0.1f);
		}

		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// M�thode requise pour la prise en charge du concepteur - ne modifiez pas
		/// le contenu de cette m�thode avec l'�diteur de code.
		/// </summary>
		private void InitializeComponent()
		{
			this.button2 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(160, 32);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(75, 25);
			this.button2.TabIndex = 1;
			this.button2.Text = "Slide >>>";
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(144, 72);
			this.label1.TabIndex = 2;
			this.label1.Text = "Click on button to slide out or in the dialog";
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(242, 87);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.label1,
																		  this.button2});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		private void button2_Click(object sender, System.EventArgs e)
		{
			_oSlideForm.SlideDirection = SlideDialog.SlideDialog.SLIDE_DIRECTION.RIGHT;
			_oSlideForm.Slide();
		}
		[STAThread]
		public static void Main()
		{
			Application.Run(new Form1());
		}

	}
}
